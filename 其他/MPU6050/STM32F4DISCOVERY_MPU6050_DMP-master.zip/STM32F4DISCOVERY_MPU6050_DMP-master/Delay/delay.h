#ifndef __DELAY_H
#define __DELAY_H

void delay_init(void);
void TimingDelay_Decrement(void);
void delay_ms(uint32_t nTime);

#endif
